 import java.util.Scanner;
import javax.swing.JOptionPane;




public class Logins {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner sc;
        sc = new Scanner(System.in);
        // Promting the user to enter the necessary info
        System.out.print("Enter your first name: "); // The first name will be entered
        String firstname =sc.next(); 
         
        System.out.print("Enter your Last name: "); // The Last name will be entered
        String lastName =sc.next();
        
        System.out.print("Create your Username: "); // The User name will be entered
        System.out.println("Your Username must contain an Underscore ");
        String Username= sc.next();
        
        System.out.println("Create your Password : ");
        System.out.println("Your password must be more than eight charcters containing  a special character and a digit");
// The Password will be entered
        String Password= sc.next();
       
        
        System.out.println("Login");
        System.out.println("Enter the Username");
        String LoginUsername=sc.next();
        System.out.println("Enter the Password");
        String LoginPassword=sc.next();
        System.out.println(checkUserName(Username));
        System.out.println(checkPasswordComplexity(Password));
        System.out.println(registerUser(Username,Password));
        System.out.println (loginUser(Username,Password, LoginUsername, LoginPassword));
        System.out.println( returnLoginStatus(Username,Password,LoginUsername,LoginPassword,firstname,lastName));
        // TODO code application logic here
      JOptionPane.showMessageDialog(null," welcome to easy Kanban");
       
         String Sc=JOptionPane.showInputDialog("a.Option 1) Add tasks "+ "\n" + "b.Option 2) Show report-  coming soon"+"\n"+"c. Option 3)Quit");
          int v=Integer.parseInt(Sc);
        while(v!=3){
            
    
        
      
       
              if(v==1){

    String project= JOptionPane.showInputDialog(null," how many tasks will you like to enter"); 
              int a=Integer.parseInt(project);
              
              
              
              
             
                     int time=0;
              for(int i=0;i<a;i++){
        
        String taskName=JOptionPane.showInputDialog( "enter task Name");
        
      JOptionPane.showMessageDialog(null, i);
      
      
      String taskDescription=JOptionPane.showInputDialog("enter task Description");
 
          if(Task.checkTaskDescription(taskDescription)==  false){
              
              JOptionPane.showMessageDialog(null,"the length should not be greater than 50","Title",JOptionPane.WARNING_MESSAGE);
             
        } 
          else{
              JOptionPane.showMessageDialog(null,"task successfully captured");
          }
    
      JOptionPane.showMessageDialog(null,Task.checkTaskDescription(taskDescription));
   
     
      String  dvFirstName= JOptionPane.showInputDialog(null,"first Name");
     
      String dvLastName= JOptionPane.showInputDialog(null,"enter last name " );
      
      
      
     
      String Duration=JOptionPane.showInputDialog("enter task duration");
     int duration=Integer.parseInt(Duration);
     time+=duration;
     
     
     
     
        JOptionPane.showMessageDialog(null,Task.createTaskID( dvFirstName, i, taskName));
        
       
 
     int taskStatus=Integer.parseInt(JOptionPane.showInputDialog("task Status" + "\n" + "1=to do" + "\n" + "2=done" + "\n" + "3=doing"));
             
             
              String option= "";
             switch (taskStatus){
                 case 1:
                     Sc="to do";
                     break;
                 case 2:
                     Sc="done";
                     break;
                 case 3:
                     Sc="Doing";
                     break;
                 default:
                     break;
             }
           
      JOptionPane.showMessageDialog(null,Task.printTaskDetails(Sc,option, dvFirstName, dvLastName, taskName, taskStatus, taskDescription, time));
        
              }
              
                 
             JOptionPane.showMessageDialog(null,Task.returnTotalHours(time, time));
    }
              if(v==2){
                  JOptionPane.showMessageDialog(null,"coming soon");
                   Sc=JOptionPane.showInputDialog("a.Option 1) Add tasks "+ "\n" + "b.Option 2) Show report-coming soon"+"\n"+"c. Option 3)Quit");
            
                   v=Integer.parseInt(Sc);
              }
            v=Integer.parseInt(JOptionPane.showInputDialog("a.Option 1) Add tasks "+ "\n" + "b.Option 2) Show report-coming soon"+"\n"+"c. Option 3)Quit"));
        
         
  }
}
    
       
        
 
    public static boolean checkUserName(String Username){
        for(int i=0;i<Username.length();i++){
            int length = Username.length();
            boolean thelength=true;
            
            if((int)Username.charAt(i)==95){
                if (length<=5){
            }
        }
    }
   return true;
    }
    public static boolean checkPasswordComplexity(String Password){
        boolean Digit=false;
        boolean uppercase=false;
        boolean Number=false;
        boolean specialCharacter=false;
         int length=Password.length();
         
         for (int i=0;i<Password.length();i++){
            
         
        if((int)Password.charAt(i)<=48 && Password.charAt(i)==57){ 
        Number=true;
        }
        
        if((int)Password.charAt(i)<=65 && Password.charAt(i)==90){ 
           uppercase=true;
        }
        if((int)Password.charAt(i)>=33 && Password.charAt(i)==64){ 
         specialCharacter =true;
        }
        if (i>=7) {
        
        }
         }
        
         if (Digit && uppercase && Number && specialCharacter && length>=8){
             return true;
         }
          return true;
    }
    
   public static String registerUser( String Username,String Password){
       if(Logins.checkUserName(Username)==false){
           return ("the username is incorrect");
           
       }
       if (Logins.checkPasswordComplexity(Password)==false){
           return("the password does not meet the complexity requirement");
       }
       else{
           return("the two above conditions have been met and the user has been registered successfully");
       }
       
   }
   
   
   public static boolean loginUser(String Username,String Password,String LoginUser,String LoginPassword){
       return LoginUser.equals(Username)&& LoginPassword.equals(Password);
   }
   public static String returnLoginStatus(String Username,String Password,String LoginUser,String LoginPassword,String firstname,String lastName){ 

   boolean login=Logins.loginUser(Username,Password,LoginUser,LoginPassword);
   if (login==true){
       return "Login Successful,Welcome " + firstname + " " + lastName +" it is great to see you!"; 
   }
   else{
       return "A failed login";
   }
   }
}
    
    

